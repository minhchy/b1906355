<html>
   
   <head>
      <title>Tính giai thừa trong PHP (Phần 1)</title>
   </head>
   <body>
   
       <?php
        $n = 10;  
        $x = 1;
	    for($i=1; $i <= $n-1; $i++)  
		{  
		 $x*=($i+1);   
		}  
		echo "Giai thừa của $n = $x"."<br>";
       ?>
       
   </body>
</html>